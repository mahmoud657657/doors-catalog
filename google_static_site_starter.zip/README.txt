
# متجر ثابت جاهز للنشر (RTL)

## التعديل السريع
- غيّر اسم المتجر والشعار من `index.html` وملف `assets/logo.jpg`.
- عدّل المنتجات والأسعار من `products.json` (احفظ بصيغة UTF-8).
- لو عندك رقم واتساب مخصص، افتح `app.js` وبدّل المتغير `phone` برقمك (مثال فلسطين: 97259xxxxxxx).

## النشر على GitHub Pages
1) افتح GitHub ثم **New repository**.
2) الاسم: `my-store` (أي اسم).
3) `Public` ثم Create.
4) ادخل للمستودع وافتح **Add file > Upload files** وارفع كل ملفات هذا القالب.
5) بعد الرفع، ادخل **Settings > Pages**.
6) من **Build and deployment** غيّر **Source** إلى **Deploy from a branch**.
7) اختر branch: **main**، والـ folder: **/** (root)، ثم Save.
8) انتظر ثوانٍ وستحصل على رابط موقعك ضمن Pages.

## النشر على أي استضافة ثابتة (Netlify, Vercel, Surge...)
ارفع نفس الملفات للمزود؛ لا يلزم باك-إند.

